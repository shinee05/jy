var song;



function preload() {
 song = loadSound("Walk Through the Park.mp3");   
}

function setup() {

}

function draw() {
   song.play(); 
}